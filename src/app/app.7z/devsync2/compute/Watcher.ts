/** this file is same with devsync module */
import DevsyncWatcher from "@root/app/devsync/compute/Watcher";

class Watcher extends DevsyncWatcher{}

export default Watcher;